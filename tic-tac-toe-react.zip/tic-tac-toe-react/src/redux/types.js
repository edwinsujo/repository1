export const TYPE_EXAMPLE = "TYPE_EXAMPLE";

export const SET_USERNAMES = "SET_USERNAMES";
